package yagni;

public class yagni1 {

}
