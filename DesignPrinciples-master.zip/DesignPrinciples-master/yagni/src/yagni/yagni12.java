package yagni;


public class yagni12 {
	public void labclass() {

		System.out.println("lab class going on now");
		performOtherTasks();
		}

		/*public void theoryclass() {
		System.out.println("theory class going on now");
		}*/

		public void performOtherTasks() {

		System.out.println("Attendence is taken");
		System.out.println("Learning is done");
		System.out.println("teaching is done");
		
		}

		} 

class Mainyagni12{
	public static void main(String[] args) {
		yagni12 obj=new yagni12();
		obj.labclass();
		//obj.theoryclass();
	}

		
		
	}
