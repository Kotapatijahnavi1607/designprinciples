package Layered;

public interface JpaRepository<T1,T2> {

}