package Layered;

public @interface RequestBody {

}