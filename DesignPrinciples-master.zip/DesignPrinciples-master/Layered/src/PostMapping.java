package Layered;

public @interface PostMapping {

}