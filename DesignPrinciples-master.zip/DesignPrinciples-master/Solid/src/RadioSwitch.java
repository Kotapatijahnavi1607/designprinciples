package solid;

public interface RadioSwitch {
void turnRadioOn();
void turnRadioOff();
}
� 2020 GitHub, Inc.