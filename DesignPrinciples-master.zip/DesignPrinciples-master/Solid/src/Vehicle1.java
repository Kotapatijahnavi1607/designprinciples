package solid;

public interface Vehicle1 {
void accelerate();
}