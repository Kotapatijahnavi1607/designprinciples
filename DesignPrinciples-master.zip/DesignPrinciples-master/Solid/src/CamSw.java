package solid;

public interface CamSw {
	void turnCameraOn();
	void turnCameraOff();

}