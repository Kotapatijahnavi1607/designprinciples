package solid;

public interface DrivingMode {

	int getPower();
	int getSuspensionHegiht();
}